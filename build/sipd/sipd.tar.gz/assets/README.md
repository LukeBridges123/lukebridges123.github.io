# SIPD
Spatial Iterated Prisoners' Dilemma in Python

Most of the actual description is in CLAUDE.md at this point, so look there.