"""
SIPD - Spatial Iterated Prisoner's Dilemma

Main entry point for the simulation.
"""

import asyncio
import pygame
import sys
import random
from strategies import (always_defect, always_cooperate, tit_for_tat, pavlov, revenger,
                        tf2t, generous, prober, Game)
from grid import Grid
from ui import DEFAULT_THEME, SimulatorUI, StatsUI, MixUI, MatchupUI, PayoffUI
from ui.components import Button


class SimulationState:
    """Manages the simulation state and parameters"""

    # Default parameter values
    DEFAULT_GRID_ROWS = 50
    DEFAULT_GRID_COLS = 50
    DEFAULT_ROUNDS = 100
    DEFAULT_MATCHES = 10
    DEFAULT_NOISE = 0.0
    DEFAULT_MUTATION = 0.0
    DEFAULT_SPEED = 10  # steps per second

    def __init__(self):
        self.strategies = [always_cooperate, always_defect, tit_for_tat, pavlov, revenger, tf2t, generous, prober]
        self.colors = {
            "Always cooperate": (46, 204, 113),    # Emerald green
            "Always defect": (231, 76, 60),         # Alizarin red
            "Tit-for-tat": (52, 152, 219),          # Peter river blue
            "Pavlov": (243, 156, 18),               # Orange
            "Revenger": (155, 89, 182),             # Amethyst purple
            "Tit-for-two-tats": (26, 188, 156),    # Turquoise
            "Generous": (241, 196, 15),             # Sunflower yellow
            "Prober": (192, 57, 43)                 # Pomegranate red
        }

        # Strategy weights for initial population (default: equal weights)
        # Keys are strategy names, values are weights (not percentages)
        self.strategy_weights = {str(s): 1.0 for s in self.strategies}

        # Payoff matrix (default: prisoner's dilemma)
        # Format: matrix[row][col] = (player1_payoff, player2_payoff)
        # Row = player 1's move (0=defect, 1=cooperate)
        # Col = player 2's move (0=defect, 1=cooperate)
        self.payoff_matrix = self._default_payoff_matrix()

        # Simulation parameters
        self.reset_parameters()

        # State tracking
        self.seed = None
        self.step_count = 0
        self.board = None
        self.paused = True  # Start paused
        self.last_auto_step = 0

        # Census history for time series
        self.census_history = []  # List of {strategy_name: percentage} dicts

        self.new_simulation(new_seed=True)

    def reset_parameters(self):
        """Reset all parameters to defaults"""
        self.grid_rows = self.DEFAULT_GRID_ROWS
        self.grid_cols = self.DEFAULT_GRID_COLS
        self.rounds = self.DEFAULT_ROUNDS
        self.matches = self.DEFAULT_MATCHES
        self.noise = self.DEFAULT_NOISE
        self.mutation_rate = self.DEFAULT_MUTATION
        self.auto_step_delay = int(1000 / self.DEFAULT_SPEED)

    def new_simulation(self, new_seed=True):
        """Start a new simulation, optionally with a new random seed"""
        if new_seed:
            self.seed = random.randint(0, 2**32 - 1)

        random.seed(self.seed)
        self.board = Grid(
            strategies=self.strategies,
            rows=self.grid_rows,
            cols=self.grid_cols,
            game=self.get_game(),
            rounds=self.rounds,
            noise=self.noise,
            mutation_rate=self.mutation_rate,
            matches=self.matches
        )

        # Build weights list in same order as strategies
        weights = [self.strategy_weights.get(str(s), 1.0) for s in self.strategies]
        self.board.populate_randomly(weights)
        self.step_count = 0

        # Reset and record initial census
        self.census_history = []
        self.record_census()

    def update_live_params(self):
        """Update parameters that can change without restart"""
        self.board.mutation_rate = self.mutation_rate
        # Note: noise requires recomputing matchup table, so it needs restart

    def step(self):
        """Advance simulation by one generation"""
        self.board.update_grid()
        self.step_count += 1
        self.record_census()

    def record_census(self):
        """Record current census to history"""
        census = self.board.get_census_percentages()
        self.census_history.append(census)

    def get_current_census(self):
        """Get current census percentages"""
        return self.board.get_census_percentages()

    def get_weight_percentages(self):
        """Get strategy weights as percentages (for display)"""
        total = sum(self.strategy_weights.values())
        if total == 0:
            # Avoid division by zero
            n = len(self.strategy_weights)
            return {name: 100.0 / n for name in self.strategy_weights}
        return {name: (w / total) * 100 for name, w in self.strategy_weights.items()}

    def reset_weights_to_equal(self):
        """Reset all strategy weights to equal"""
        self.strategy_weights = {str(s): 1.0 for s in self.strategies}

    def _default_payoff_matrix(self):
        """Return the default prisoner's dilemma payoff matrix"""
        return [
            [(1, 1), (5, 0)],  # Row 0 (Defect): vs Defect, vs Cooperate
            [(0, 5), (3, 3)]   # Row 1 (Cooperate): vs Defect, vs Cooperate
        ]

    def reset_payoff_matrix(self):
        """Reset payoff matrix to default prisoner's dilemma"""
        self.payoff_matrix = self._default_payoff_matrix()

    def get_game(self):
        """Get a Game object from the current payoff matrix"""
        return Game(self.payoff_matrix)


# Screen modes
SCREEN_SIMULATOR = 0
SCREEN_STATS = 1
SCREEN_MIX = 2
SCREEN_MATCHUP = 3
SCREEN_PAYOFF = 4


async def main():
    """Main event loop"""
    sim = SimulationState()
    sim_ui = SimulatorUI(sim, DEFAULT_THEME)
    stats_ui = StatsUI(sim, DEFAULT_THEME)
    mix_ui = MixUI(sim, DEFAULT_THEME)
    matchup_ui = MatchupUI(sim, DEFAULT_THEME)
    payoff_ui = PayoffUI(sim, DEFAULT_THEME)

    # Current screen
    current_screen = SCREEN_SIMULATOR

    # View toggle button layout constants (matching SimulatorUI)
    btn_width = 90
    btn_spacing = 10
    btn_y_offset = 60  # Offset from top of bottom panel

    # Create screen toggle buttons (positioned to the left of the Reset button)
    # Reset button is at window_width - btn_width - padding, so we start from there
    def get_view_btn_x(index):
        """Get x position for view toggle button by index (0 = rightmost)"""
        # Start from Reset button position and go left
        reset_x = sim_ui.window_width - btn_width - sim_ui.padding
        return reset_x - (index + 1) * (btn_width + btn_spacing)

    btn_stats = Button(
        get_view_btn_x(0), sim_ui.window_height - sim_ui.bottom_panel_height + btn_y_offset,
        btn_width, 28, "Stats", (80, 100, 120), (100, 130, 160)
    )
    btn_mix = Button(
        get_view_btn_x(1), sim_ui.window_height - sim_ui.bottom_panel_height + btn_y_offset,
        btn_width, 28, "Mix", (100, 80, 120), (130, 100, 160)
    )
    btn_matchup = Button(
        get_view_btn_x(2), sim_ui.window_height - sim_ui.bottom_panel_height + btn_y_offset,
        btn_width, 28, "Matchup", (100, 100, 80), (130, 130, 100)
    )
    btn_payoff = Button(
        get_view_btn_x(3), sim_ui.window_height - sim_ui.bottom_panel_height + btn_y_offset,
        btn_width, 28, "Payoff", (80, 100, 100), (100, 130, 130)
    )

    # List of view buttons for easy iteration (rightmost to leftmost)
    view_buttons = [btn_stats, btn_mix, btn_matchup, btn_payoff]

    def update_button_positions():
        """Update button positions after window/grid changes"""
        btn_y = sim_ui.window_height - sim_ui.bottom_panel_height + btn_y_offset
        for i, btn in enumerate(view_buttons):
            btn.rect.x = get_view_btn_x(i)
            btn.rect.y = btn_y

    running = True
    pending_restart = False  # Track if we need to restart after param changes

    while running:
        current_time = pygame.time.get_ticks()
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.VIDEORESIZE:
                sim_ui.handle_resize(event.w, event.h)
                sim_ui.window = pygame.display.set_mode(
                    (sim_ui.window_width, sim_ui.window_height),
                    pygame.RESIZABLE
                )
                update_button_positions()

            elif event.type == pygame.KEYDOWN:
                # S key toggles stats view
                if event.key == pygame.K_s:
                    # If on stats, go to simulator; otherwise go to stats
                    current_screen = SCREEN_SIMULATOR if current_screen == SCREEN_STATS else SCREEN_STATS
                    btn_stats.text = "Grid" if current_screen == SCREEN_STATS else "Stats"
                    btn_mix.text = "Mix"
                    btn_matchup.text = "Matchup"
                    btn_payoff.text = "Payoff"
                    continue

                # M key toggles mix view
                if event.key == pygame.K_m:
                    # If on mix, go to simulator; otherwise go to mix
                    current_screen = SCREEN_SIMULATOR if current_screen == SCREEN_MIX else SCREEN_MIX
                    btn_mix.text = "Grid" if current_screen == SCREEN_MIX else "Mix"
                    btn_stats.text = "Stats"
                    btn_matchup.text = "Matchup"
                    btn_payoff.text = "Payoff"
                    continue

                # U key toggles matchup view
                if event.key == pygame.K_u:
                    # If on matchup, go to simulator; otherwise go to matchup
                    current_screen = SCREEN_SIMULATOR if current_screen == SCREEN_MATCHUP else SCREEN_MATCHUP
                    btn_matchup.text = "Grid" if current_screen == SCREEN_MATCHUP else "Matchup"
                    btn_stats.text = "Stats"
                    btn_mix.text = "Mix"
                    btn_payoff.text = "Payoff"
                    continue

                # Y key toggles payoff view
                if event.key == pygame.K_y:
                    # If on payoff, go to simulator; otherwise go to payoff
                    current_screen = SCREEN_SIMULATOR if current_screen == SCREEN_PAYOFF else SCREEN_PAYOFF
                    btn_payoff.text = "Grid" if current_screen == SCREEN_PAYOFF else "Payoff"
                    btn_stats.text = "Stats"
                    btn_mix.text = "Mix"
                    btn_matchup.text = "Matchup"
                    continue

                # ESC returns to simulator from other screens, or quits from simulator
                if event.key == pygame.K_ESCAPE:
                    if current_screen in (SCREEN_STATS, SCREEN_MIX, SCREEN_MATCHUP, SCREEN_PAYOFF):
                        current_screen = SCREEN_SIMULATOR
                        btn_stats.text = "Stats"
                        btn_mix.text = "Mix"
                        btn_matchup.text = "Matchup"
                        btn_payoff.text = "Payoff"
                    else:
                        running = False
                    continue

                # These controls work in both views
                if event.key == pygame.K_SPACE:
                    sim.step()
                elif event.key == pygame.K_p:
                    sim.paused = not sim.paused
                elif event.key == pygame.K_r:
                    sim.new_simulation(new_seed=False)
                    sim_ui.resize_window_to_fit_grid()
                    update_button_positions()
                    pending_restart = False
                elif event.key == pygame.K_n:
                    sim.new_simulation(new_seed=True)
                    sim_ui.resize_window_to_fit_grid()
                    update_button_positions()
                    pending_restart = False

                # Parameter editing only in simulator view
                if current_screen == SCREEN_SIMULATOR:
                    done, _changed, needs_restart = sim_ui.handle_param_text_input(event)
                    if done and needs_restart:
                        pending_restart = True

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:  # Left click release
                    if current_screen == SCREEN_MIX:
                        mix_ui.handle_mouse_up()

            elif event.type == pygame.MOUSEMOTION:
                if current_screen == SCREEN_MIX:
                    mix_ui.handle_mouse_motion(mouse_pos)

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left click
                    # Check stats toggle button (works in all views)
                    if btn_stats.is_clicked(mouse_pos, True):
                        # If on stats, go to simulator; otherwise go to stats
                        current_screen = SCREEN_SIMULATOR if current_screen == SCREEN_STATS else SCREEN_STATS
                        btn_stats.text = "Grid" if current_screen == SCREEN_STATS else "Stats"
                        btn_mix.text = "Mix"
                        btn_matchup.text = "Matchup"
                        btn_payoff.text = "Payoff"
                        continue

                    # Check mix toggle button (works in all views)
                    if btn_mix.is_clicked(mouse_pos, True):
                        # If on mix, go to simulator; otherwise go to mix
                        current_screen = SCREEN_SIMULATOR if current_screen == SCREEN_MIX else SCREEN_MIX
                        btn_mix.text = "Grid" if current_screen == SCREEN_MIX else "Mix"
                        btn_stats.text = "Stats"
                        btn_matchup.text = "Matchup"
                        btn_payoff.text = "Payoff"
                        continue

                    # Check matchup toggle button (works in all views)
                    if btn_matchup.is_clicked(mouse_pos, True):
                        # If on matchup, go to simulator; otherwise go to matchup
                        current_screen = SCREEN_SIMULATOR if current_screen == SCREEN_MATCHUP else SCREEN_MATCHUP
                        btn_matchup.text = "Grid" if current_screen == SCREEN_MATCHUP else "Matchup"
                        btn_stats.text = "Stats"
                        btn_mix.text = "Mix"
                        btn_payoff.text = "Payoff"
                        continue

                    # Check payoff toggle button (works in all views)
                    if btn_payoff.is_clicked(mouse_pos, True):
                        # If on payoff, go to simulator; otherwise go to payoff
                        current_screen = SCREEN_SIMULATOR if current_screen == SCREEN_PAYOFF else SCREEN_PAYOFF
                        btn_payoff.text = "Grid" if current_screen == SCREEN_PAYOFF else "Payoff"
                        btn_stats.text = "Stats"
                        btn_mix.text = "Mix"
                        btn_matchup.text = "Matchup"
                        continue

                    # Mix screen mouse handling
                    if current_screen == SCREEN_MIX:
                        mix_ui.handle_mouse_down(mouse_pos)
                        continue

                    # Payoff screen mouse handling
                    if current_screen == SCREEN_PAYOFF:
                        payoff_ui.handle_mouse_down(mouse_pos)
                        continue

                    # Simulator-specific button handling
                    if current_screen == SCREEN_SIMULATOR:
                        # Check for double-click on parameters first
                        click_time = pygame.time.get_ticks()
                        if hasattr(sim_ui, '_last_click_time') and hasattr(sim_ui, '_last_click_pos'):
                            time_diff = click_time - sim_ui._last_click_time
                            pos_diff = ((mouse_pos[0] - sim_ui._last_click_pos[0])**2 +
                                      (mouse_pos[1] - sim_ui._last_click_pos[1])**2)**0.5
                            if time_diff < 400 and pos_diff < 10:  # Double-click detected
                                sim_ui.handle_param_double_click(mouse_pos)
                                sim_ui._last_click_time = 0  # Reset to prevent triple-click
                                continue
                        sim_ui._last_click_time = click_time
                        sim_ui._last_click_pos = mouse_pos

                        # Check main buttons
                        if sim_ui.btn_step.is_clicked(mouse_pos, True):
                            sim.step()
                        elif sim_ui.btn_play.is_clicked(mouse_pos, True):
                            sim.paused = not sim.paused
                        elif sim_ui.btn_restart_same.is_clicked(mouse_pos, True):
                            sim.new_simulation(new_seed=False)
                            sim_ui.resize_window_to_fit_grid()
                            update_button_positions()
                            pending_restart = False
                        elif sim_ui.btn_new_seed.is_clicked(mouse_pos, True):
                            sim.new_simulation(new_seed=True)
                            sim_ui.resize_window_to_fit_grid()
                            update_button_positions()
                            pending_restart = False
                        elif sim_ui.btn_reset.is_clicked(mouse_pos, True):
                            sim_ui.reset_params_to_defaults()
                            pending_restart = True  # Params changed, need restart
                        else:
                            # Check parameter controls
                            changed, needs_restart = sim_ui.handle_param_click(mouse_pos)
                            if needs_restart:
                                pending_restart = True

        # Update hover states
        btn_stats.update(mouse_pos)
        btn_mix.update(mouse_pos)
        btn_matchup.update(mouse_pos)
        btn_payoff.update(mouse_pos)
        if current_screen == SCREEN_SIMULATOR:
            sim_ui.update_controls(mouse_pos)
        elif current_screen == SCREEN_MIX:
            mix_ui.update(mouse_pos)
        elif current_screen == SCREEN_MATCHUP:
            matchup_ui.update(mouse_pos)
        elif current_screen == SCREEN_PAYOFF:
            payoff_ui.update(mouse_pos)

        # Auto-step when not paused
        if not sim.paused and current_time - sim.last_auto_step >= sim.auto_step_delay:
            sim.step()
            sim.last_auto_step = current_time

        # Draw current screen
        if current_screen == SCREEN_SIMULATOR:
            sim_ui.draw()

            # Draw restart pending indicator if needed
            if pending_restart:
                indicator_text = sim_ui.theme.font_small.render(
                    "Parameters changed - press R or N to apply",
                    True, (220, 180, 80)
                )
                sim_ui.window.blit(indicator_text, (sim_ui.padding, sim_ui.window_height - sim_ui.bottom_panel_height + 40))

        elif current_screen == SCREEN_STATS:
            # Draw stats on same window
            sim_ui.window.fill(DEFAULT_THEME.BG_COLOR)
            stats_ui.draw(sim_ui.window, sim_ui.window_width, sim_ui.window_height, sim_ui.bottom_panel_height)

            # Draw bottom panel (simplified version for stats view)
            panel_y = sim_ui.window_height - sim_ui.bottom_panel_height
            pygame.draw.rect(sim_ui.window, DEFAULT_THEME.PANEL_COLOR, (0, panel_y, sim_ui.window_width, sim_ui.bottom_panel_height))
            pygame.draw.line(sim_ui.window, (60, 60, 65), (0, panel_y), (sim_ui.window_width, panel_y), 2)

            # Generation counter
            gen_text = DEFAULT_THEME.font_title.render(f"Generation: {sim.step_count}", True, DEFAULT_THEME.TEXT_COLOR)
            sim_ui.window.blit(gen_text, (sim_ui.padding, panel_y + 15))

            # Status indicator
            status = "PAUSED" if sim.paused else "RUNNING"
            status_color = (180, 180, 60) if sim.paused else (60, 180, 100)
            status_text = DEFAULT_THEME.font_medium.render(status, True, status_color)
            sim_ui.window.blit(status_text, (sim_ui.padding + 220, panel_y + 18))

            # Controls help for stats view
            controls_text = DEFAULT_THEME.font_small.render(
                "S: Toggle View | SPACE: Step | P: Play/Pause | R: Restart | ESC: Back",
                True, DEFAULT_THEME.TEXT_DIM_COLOR
            )
            sim_ui.window.blit(controls_text, (sim_ui.padding, panel_y + 95))

        elif current_screen == SCREEN_MIX:
            # Draw mix configuration screen
            sim_ui.window.fill(DEFAULT_THEME.BG_COLOR)
            mix_ui.draw(sim_ui.window, sim_ui.window_width, sim_ui.window_height, sim_ui.bottom_panel_height)

            # Draw bottom panel for mix view
            panel_y = sim_ui.window_height - sim_ui.bottom_panel_height
            pygame.draw.rect(sim_ui.window, DEFAULT_THEME.PANEL_COLOR, (0, panel_y, sim_ui.window_width, sim_ui.bottom_panel_height))
            pygame.draw.line(sim_ui.window, (60, 60, 65), (0, panel_y), (sim_ui.window_width, panel_y), 2)

            # Title
            title_text = DEFAULT_THEME.font_title.render("Configure Starting Mix", True, DEFAULT_THEME.TEXT_COLOR)
            sim_ui.window.blit(title_text, (sim_ui.padding, panel_y + 15))

            # Hint about applying
            hint_text = DEFAULT_THEME.font_medium.render(
                "Press R or N to start simulation with this mix",
                True, (180, 180, 60)
            )
            sim_ui.window.blit(hint_text, (sim_ui.padding, panel_y + 50))

            # Controls help for mix view
            controls_text = DEFAULT_THEME.font_small.render(
                "M: Toggle View | R: Restart (same seed) | N: New Seed | ESC: Back",
                True, DEFAULT_THEME.TEXT_DIM_COLOR
            )
            sim_ui.window.blit(controls_text, (sim_ui.padding, panel_y + 95))

        elif current_screen == SCREEN_MATCHUP:
            # Draw matchup table screen
            sim_ui.window.fill(DEFAULT_THEME.BG_COLOR)
            matchup_ui.draw(sim_ui.window, sim_ui.window_width, sim_ui.window_height, sim_ui.bottom_panel_height)

            # Draw bottom panel for matchup view
            panel_y = sim_ui.window_height - sim_ui.bottom_panel_height
            pygame.draw.rect(sim_ui.window, DEFAULT_THEME.PANEL_COLOR, (0, panel_y, sim_ui.window_width, sim_ui.bottom_panel_height))
            pygame.draw.line(sim_ui.window, (60, 60, 65), (0, panel_y), (sim_ui.window_width, panel_y), 2)

            # Title
            title_text = DEFAULT_THEME.font_title.render("Strategy Matchups", True, DEFAULT_THEME.TEXT_COLOR)
            sim_ui.window.blit(title_text, (sim_ui.padding, panel_y + 15))

            # Subtitle
            subtitle_text = DEFAULT_THEME.font_medium.render(
                f"Based on {sim.rounds} rounds/match, {sim.matches} matches, {sim.noise:.1%} noise",
                True, DEFAULT_THEME.TEXT_DIM_COLOR
            )
            sim_ui.window.blit(subtitle_text, (sim_ui.padding, panel_y + 50))

            # Controls help for matchup view
            controls_text = DEFAULT_THEME.font_small.render(
                "U: Toggle View | SPACE: Step | P: Play/Pause | R: Restart | ESC: Back",
                True, DEFAULT_THEME.TEXT_DIM_COLOR
            )
            sim_ui.window.blit(controls_text, (sim_ui.padding, panel_y + 95))

        elif current_screen == SCREEN_PAYOFF:
            # Draw payoff matrix editor screen
            sim_ui.window.fill(DEFAULT_THEME.BG_COLOR)
            payoff_ui.draw(sim_ui.window, sim_ui.window_width, sim_ui.window_height, sim_ui.bottom_panel_height)

            # Draw bottom panel for payoff view
            panel_y = sim_ui.window_height - sim_ui.bottom_panel_height
            pygame.draw.rect(sim_ui.window, DEFAULT_THEME.PANEL_COLOR, (0, panel_y, sim_ui.window_width, sim_ui.bottom_panel_height))
            pygame.draw.line(sim_ui.window, (60, 60, 65), (0, panel_y), (sim_ui.window_width, panel_y), 2)

            # Title
            title_text = DEFAULT_THEME.font_title.render("Edit Payoff Matrix", True, DEFAULT_THEME.TEXT_COLOR)
            sim_ui.window.blit(title_text, (sim_ui.padding, panel_y + 15))

            # Hint about applying
            hint_text = DEFAULT_THEME.font_medium.render(
                "Press R or N to apply changes to simulation",
                True, (180, 180, 60)
            )
            sim_ui.window.blit(hint_text, (sim_ui.padding, panel_y + 50))

            # Controls help for payoff view
            controls_text = DEFAULT_THEME.font_small.render(
                "Y: Toggle View | R: Restart (same seed) | N: New Seed | ESC: Back",
                True, DEFAULT_THEME.TEXT_DIM_COLOR
            )
            sim_ui.window.blit(controls_text, (sim_ui.padding, panel_y + 95))

        # Draw screen toggle buttons (in all views)
        btn_stats.draw(sim_ui.window, DEFAULT_THEME.font_medium)
        btn_mix.draw(sim_ui.window, DEFAULT_THEME.font_medium)
        btn_matchup.draw(sim_ui.window, DEFAULT_THEME.font_medium)
        btn_payoff.draw(sim_ui.window, DEFAULT_THEME.font_medium)

        pygame.display.flip()
        await asyncio.sleep(0)
        sim_ui.clock.tick(60)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    asyncio.run(main())
